import{E as o}from"./B4BepZ-8.js";const p=o("/logo.jpg");export{p as _};
